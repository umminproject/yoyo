package com.naver.kus.service;

public interface DoctorDao {
	public int selectCount(String d_id);
}
